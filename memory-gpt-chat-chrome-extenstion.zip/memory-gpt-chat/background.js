// Memory GPT Chat — Background (service worker)
// Handles reliable exports via chrome.downloads even if popup closes.

function nowStamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(
    d.getHours()
  )}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

chrome.runtime.onInstalled.addListener(() => {
  // Reserved for any future defaults/migrations
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "EXPORT_JSON") {
    (async () => {
      try {
        const payload = Array.isArray(msg.payload) ? msg.payload : [];
        const data = JSON.stringify(payload, null, 2);
        const filename = `${
          msg.filenamePrefix || "memory-gpt-chat"
        }-backup-${nowStamp()}.json`;
        const dataUrl =
          "data:application/json;charset=utf-8," + encodeURIComponent(data);

        chrome.downloads.download(
          { url: dataUrl, filename, saveAs: false, conflictAction: "uniquify" },
          (id) => {
            if (chrome.runtime.lastError) {
              sendResponse({
                ok: false,
                error: chrome.runtime.lastError.message
              });
            } else {
              sendResponse({ ok: true, id });
            }
          }
        );
      } catch (e) {
        sendResponse({ ok: false, error: e.message || "Export failed" });
      }
    })();
    return true; // keep message channel open for async sendResponse
  }
});

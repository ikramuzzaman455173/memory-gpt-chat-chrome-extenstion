/******************************************
 * Memory GPT Chat — popup.js (v4.0.0)
 * Storage upgraded to chrome.storage.local (~10MB)
 * Includes: migration from sync, storage meter, import/export,
 * duplicate prevention with URL normalization, clear-all auto-backup.
 ******************************************/

/* ---------- Constants & selectors ---------- */
const APP = "[MGC]";

// Storage keys
const KEY = "memorygpt_items_v2"; // bookmarks array (lives in local)
const THEME_KEY = "memorygpt_theme_dark"; // small flag (lives in sync)
const HELP_KEY = "memorygpt_help_hide"; // small flag (lives in sync)
const MIGRATED_KEY = "memorygpt_migrated_to_local_v1";

// Storage areas
const STORAGE_ITEMS = chrome.storage.local; // large data here (≈10MB)
const STORAGE_FLAGS = chrome.storage.sync; // tiny flags (sync across devices)

// Quotas (approximate)
const LOCAL_QUOTA_BYTES = 10 * 1024 * 1024; // 10 MB

// State
let ITEMS = [];
let sortBy = "newest"; // 'newest' | 'title'
let pageSize = 10;
let currentPage = 1;

// Shorthand
const $ = (s) => document.querySelector(s);
const byId = (id) => document.getElementById(id);

// Top status bar
const statusBar = byId("statusBar");

// Logging
const log = (...a) => console.log(APP, ...a);
const warn = (...a) => console.warn(APP, ...a);
const err = (...a) => console.error(APP, ...a);

/* ---------- Utils ---------- */
function showStatus(msg, type = "info") {
  if (!statusBar) return;
  statusBar.textContent = msg || "";
  statusBar.classList.remove("warn", "error");
  statusBar.classList.add("show");
  if (type === "warn") statusBar.classList.add("warn");
  if (type === "error") statusBar.classList.add("error");
  if (msg)
    setTimeout(() => {
      statusBar.classList.remove("show", "warn", "error");
      statusBar.textContent = "";
    }, 3200);
}

function openModal(el, show = true) {
  if (!el) return;
  el.classList.toggle("show", !!show);
  el.setAttribute("aria-hidden", show ? "false" : "true");
}

function nowStamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(
    d.getHours()
  )}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

/** Normalize chat URL: strip query/hash, trailing slash; map host to chatgpt.com */
function normalizeUrl(url = "") {
  try {
    const u = new URL(url);
    if (!["chatgpt.com", "chat.openai.com"].includes(u.hostname)) return url;
    if (!u.pathname.startsWith("/c/")) return url;
    u.search = "";
    u.hash = "";
    if (u.pathname.length > 3 && u.pathname.endsWith("/"))
      u.pathname = u.pathname.slice(0, -1);
    u.hostname = "chatgpt.com";
    return u.toString();
  } catch {
    return url;
  }
}

function isChatUrl(url = "") {
  try {
    const u = new URL(url);
    return (
      ["chatgpt.com", "chat.openai.com"].includes(u.hostname) &&
      u.pathname.startsWith("/c/")
    );
  } catch {
    return false;
  }
}

function bytesOf(obj) {
  try {
    return new TextEncoder().encode(JSON.stringify(obj)).length;
  } catch {
    return JSON.stringify(obj || "").length;
  }
}

function humanKB(bytes) {
  if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(2) + " MB";
  return Math.ceil(bytes / 1024) + " KB";
}

/* ---------- Storage meter UI ---------- */
function updateStorageUI() {
  const totalChats = (ITEMS || []).length;
  const usedBytes = bytesOf(ITEMS);
  const percent = Math.min(
    100,
    Math.round((usedBytes / LOCAL_QUOTA_BYTES) * 100)
  );

  const elCount = byId("totalChats");
  const elUsed = byId("storageUsedLabel");
  const elLimit = byId("storageLimitLabel");
  const elMeter = byId("storageMeter");
  const elHint = byId("storageHint");

  if (elCount) elCount.textContent = String(totalChats);
  if (elUsed) elUsed.textContent = humanKB(usedBytes);
  if (elLimit) elLimit.textContent = humanKB(LOCAL_QUOTA_BYTES);

  if (elMeter) {
    elMeter.style.width = percent + "%";
    elMeter.classList.remove("warn", "danger");
    if (percent >= 90) elMeter.classList.add("danger");
    else if (percent >= 70) elMeter.classList.add("warn");
  }
  if (elHint) {
    elHint.textContent =
      percent >= 90
        ? "Large usage detected. Consider exporting a backup regularly."
        : "";
  }
}

/* ---------- Storage (bookmarks in local) ---------- */
async function loadItems() {
  try {
    const res = await STORAGE_ITEMS.get({ [KEY]: [] });
    let list = Array.isArray(res[KEY]) ? res[KEY] : [];
    list = list
      .map((x) => (x ? { ...x, url: normalizeUrl(x.url || "") } : x))
      .filter(
        (v) => v && typeof v.url === "string" && typeof v.title === "string"
      );
    log("Loaded items:", list.length);
    return list;
  } catch (e) {
    err("loadItems(local) failed:", e);
    showStatus("Load failed (see console).", "error");
    return [];
  }
}

async function saveItems(items) {
  try {
    await STORAGE_ITEMS.set({ [KEY]: items });
    updateStorageUI();
    log("Saved items:", items.length);
  } catch (e) {
    err("saveItems(local) failed:", e);
    showStatus("Save failed (see console).", "error");
  }
}

/* ---------- One-time migration: sync → local ---------- */
async function migrateFromSyncToLocalIfNeeded() {
  try {
    const flag = await STORAGE_ITEMS.get({ [MIGRATED_KEY]: false });
    if (flag[MIGRATED_KEY]) return;

    const syncData = await chrome.storage.sync.get({ [KEY]: [] });
    const oldList = Array.isArray(syncData[KEY]) ? syncData[KEY] : [];
    if (!oldList.length) {
      await STORAGE_ITEMS.set({ [MIGRATED_KEY]: true });
      return;
    }

    const localData = await STORAGE_ITEMS.get({ [KEY]: [] });
    const localList = Array.isArray(localData[KEY]) ? localData[KEY] : [];

    const seen = new Set(localList.map((i) => normalizeUrl(i.url || "")));
    const merged = [...localList];

    for (const raw of oldList) {
      if (!raw || typeof raw.url !== "string") continue;
      const url = normalizeUrl(raw.url);
      if (!url || seen.has(url)) continue;
      merged.push({
        id: raw.id || crypto.randomUUID(),
        url,
        title: raw.title || url,
        note: typeof raw.note === "string" ? raw.note : "",
        createdAt:
          raw.createdAt && !isNaN(Date.parse(raw.createdAt))
            ? raw.createdAt
            : new Date().toISOString()
      });
      seen.add(url);
    }

    await STORAGE_ITEMS.set({ [KEY]: merged, [MIGRATED_KEY]: true });
    await chrome.storage.sync.remove([KEY]); // free the old ~100KB
    log("Migration sync → local complete. Items:", merged.length);
    showStatus("Storage upgraded (10MB).", "info");
  } catch (e) {
    warn("Migration failed (safe to continue):", e);
  }
}

/* ---------- Sorting & pagination ---------- */
function sortItems(list) {
  if (sortBy === "title")
    return [...list].sort((a, b) =>
      (a.title || "").localeCompare(b.title || "")
    );
  return [...list].sort(
    (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
  ); // newest
}

function paginate(list) {
  const total = list.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (currentPage > pages) currentPage = pages;
  const start = (currentPage - 1) * pageSize;
  return { page: list.slice(start, start + pageSize), total, pages };
}

/* ---------- Render ---------- */
function render() {
  const q = (byId("searchBar").value || "").toLowerCase().trim();
  let list = ITEMS.filter(
    (x) =>
      (x.title || "").toLowerCase().includes(q) ||
      (x.note || "").toLowerCase().includes(q)
  );

  list = sortItems(list);
  const { page, pages } = paginate(list);

  const root = byId("list");
  root.innerHTML = "";

  if (!page.length) {
    const div = document.createElement("div");
    div.className = "empty";
    div.textContent = q
      ? "No results."
      : "No bookmarks yet. Open a ChatGPT chat and click Save.";
    root.appendChild(div);
  } else {
    page.forEach((item) => {
      const card = document.createElement("div");
      card.className = "card";
      card.setAttribute("data-id", item.id);
      card.innerHTML = `
        <div class="row">
          <a href="${item.url}" class="card-title" target="_blank" title="${
        item.url
      }">${item.title || item.url}</a>
          <div class="actions" role="group" aria-label="Item actions">
            <button class="btn" data-act="copy"  title="Copy link"   aria-label="Copy link">
              <span class="svg-icon"><svg viewBox="0 0 512 512"><path d="M336 64H128c-35 0-64 29-64 64v208c0 13 11 24 24 24s24-11 24-24V128c0-8.8 7.2-16 16-16h208c13.3 0 24-10.7 24-24s-10.7-24-24-24zM384 128H192c-35 0-64 29-64 64v224c0 35 29 64 64 64h192c35 0 64-29 64-64V192c0-35-29-64-64-64zm16 288c0 8.8-7.2 16-16 16H192c-8.8 0-16-7.2-16-16V192c0-8.8 7.2-16 16-16h192c8.8 0 16 7.2 16 16v224z"/></svg></span>
            </button>
            <button class="btn" data-act="open"  title="Open" aria-label="Open">
              <span class="svg-icon"><svg viewBox="0 0 512 512"><path d="M432 320c-13.3 0-24 10.7-24 24v80H104V104h80c13.3 0 24-10.7 24-24S197.3 56 184 56H80C62.3 56 48 70.3 48 88v336c0 17.7 14.3 32 32 32h336c17.7 0 32-14.3 32-32v-80c0-13.3-10.7-24-24-24zM456 16H328c-21.4 0-32.1 25.9-17 41l40.3 40.3L216.5 212.1c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0L385.2 131l40.3 40.3c15.2 15.2 41 4.4 41-17V40c0-13.3-10.7-24-24-24z"/></svg></span>
            </button>
            <button class="btn" data-act="edit"  title="Edit" aria-label="Edit">
              <span class="svg-icon"><svg viewBox="0 0 512 512"><path d="M362.7 19.3c25.8-25.8 67.7-25.8 93.5 0l36.5 36.5c25.8 25.8 25.8 67.7 0 93.5L210.2 431.8c-6 6-13.4 10.3-21.6 12.4l-98.6 24.7c-15.9 4-31.6-10.6-27.6-26.6l24.7-98.6c2.1-8.2 6.4-15.6 12.4-21.6L362.7 19.3zM80 416l63.1-15.8L111.8 368 80 416z"/></svg></span>
            </button>
            <button class="btn" data-act="clear" title="Clear chat" aria-label="Clear chat">
              <span class="svg-icon"><svg viewBox="0 0 448 512"><path d="M135.2 17.7c3.9-10.7 14-17.7 25.4-17.7h126.8c11.4 0 21.5 7 25.4 17.7L328 32H432c8.8 0 16 7.2 16 16s-7.2 16-16 16H416l-21.2 339.1c-1.6 25.2-22.6 44.9-47.9 44.9H101.1c-25.2 0-46.3-19.7-47.9-44.9L32 64H16C7.2 64 0 56.8 0 48S7.2 32 16 32H120l15.2-14.3z"/></svg></span>
            </button>
          </div>
        </div>
        <div class="meta">Saved: ${new Date(
          item.createdAt
        ).toLocaleString()}</div>
        ${item.note ? `<div class="note">${item.note}</div>` : ""}
      `;

      card.querySelectorAll(".actions .btn").forEach((btn) => {
        const handler = async () => {
          const act = btn.getAttribute("data-act");
          try {
            if (act === "copy") {
              await navigator.clipboard.writeText(item.url);
              showStatus("Link copied!");
            } else if (act === "open") {
              await chrome.tabs.create({ url: item.url });
            } else if (act === "edit") {
              const newTitle = prompt("Edit title:", item.title) ?? item.title;
              const newNote =
                prompt("Edit note:", item.note || "") ?? item.note;
              item.title = newTitle;
              item.note = newNote;
              await saveItems(ITEMS);
              render();
              showStatus("Updated.");
            } else if (act === "clear") {
              if (!confirm("Clear this saved chat?")) return;
              ITEMS = ITEMS.filter((x) => x.id !== item.id);
              await saveItems(ITEMS);
              // keep pagination stable when removing last item
              const q2 = (byId("searchBar").value || "").toLowerCase().trim();
              const remaining = ITEMS.filter(
                (x) =>
                  (x.title || "").toLowerCase().includes(q2) ||
                  (x.note || "").toLowerCase().includes(q2)
              );
              const maxPages = Math.max(
                1,
                Math.ceil(remaining.length / pageSize)
              );
              if (currentPage > maxPages) currentPage = maxPages;
              render();
              showStatus("Chat cleared.");
            }
          } catch (e) {
            err(`${act} failed:`, e);
            showStatus(`${act} failed (see console).`, "error");
          }
        };
        btn.addEventListener("click", handler);
        btn.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            handler();
          }
        });
      });

      root.appendChild(card);
    });
  }

  byId("pageLabel").textContent = `Page ${currentPage} of ${pages}`;
  byId("prevBtn").disabled = currentPage <= 1;
  byId("nextBtn").disabled = currentPage >= pages;
}

/* ---------- Duplicate scroll & highlight ---------- */
function focusAndFlashItem(targetId) {
  const searchInput = byId("searchBar");
  if (searchInput.value) searchInput.value = "";

  const sorted = sortItems(ITEMS);
  const idx = sorted.findIndex((i) => i.id === targetId);
  if (idx >= 0) {
    currentPage = Math.floor(idx / pageSize) + 1;
    render();
    const el = document.querySelector(`[data-id="${targetId}"]`);
    if (el) {
      el.classList.add("flash");
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => el.classList.remove("flash"), 1600);
    }
  } else {
    render();
  }
}

/* ---------- Export / Import ---------- */
async function exportItems(filenamePrefix = "memory-gpt-chat") {
  try {
    const data = JSON.stringify(ITEMS, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const filename = `${filenamePrefix}-backup-${nowStamp()}.json`;

    if (chrome.downloads && chrome.downloads.download) {
      await chrome.downloads.download({
        url,
        filename,
        saveAs: false,
        conflictAction: "uniquify"
      });
    } else {
      // Fallback (rare): anchor download
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
    }
    showStatus("Backup export started.");
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return true;
  } catch (e) {
    err("Export failed:", e);
    showStatus("Export failed (see console).", "error");
    return false;
  }
}

async function handleImportFile(file) {
  if (!file) return;
  try {
    const text = await file.text();
    const incoming = JSON.parse(text);
    if (!Array.isArray(incoming))
      throw new Error("Invalid file format (expected array)");

    // Normalize existing + build seen set
    ITEMS = ITEMS.map((i) => ({ ...i, url: normalizeUrl(i.url) }));
    const seen = new Set(ITEMS.map((i) => i.url));

    let added = 0,
      skipped = 0;
    for (const raw of incoming) {
      if (!raw || typeof raw.url !== "string") {
        skipped++;
        continue;
      }
      const url = normalizeUrl(raw.url);
      if (!isChatUrl(url)) {
        skipped++;
        continue;
      }
      if (seen.has(url)) {
        skipped++;
        continue;
      }
      const item = {
        id: crypto.randomUUID(),
        url,
        title: typeof raw.title === "string" && raw.title ? raw.title : url,
        note: typeof raw.note === "string" ? raw.note : "",
        createdAt:
          raw.createdAt && !isNaN(Date.parse(raw.createdAt))
            ? raw.createdAt
            : new Date().toISOString()
      };
      ITEMS.push(item);
      seen.add(url);
      added++;
    }
    await saveItems(ITEMS);
    currentPage = 1;
    render();
    showStatus(`Import complete: ${added} added, ${skipped} skipped.`);
  } catch (e) {
    err("Import failed:", e);
    showStatus("Import failed (see console).", "error");
  } finally {
    const f = byId("importFile");
    if (f) f.value = ""; // reset
  }
}

/* ---------- Clear All with confirm + auto-backup ---------- */
function openClearAllModal() {
  const modal = byId("clearAllModal");
  const input = byId("clearAllInput");
  const confirmBtn = byId("clearAllConfirm");
  if (!modal || !input || !confirmBtn) return;

  input.value = "";
  confirmBtn.disabled = true;
  openModal(modal, true);

  input.oninput = () => {
    const v = input.value.trim().toLowerCase();
    confirmBtn.disabled = v !== "yes clear all";
  };
}

async function confirmClearAll() {
  try {
    // 1) Export backup first; if export fails => abort clearing
    const ok = await exportItems("memory-gpt-chat");
    if (!ok) {
      showStatus("Backup failed — nothing cleared.", "error");
      return;
    }

    // 2) Clear data
    ITEMS = [];
    await saveItems(ITEMS);
    currentPage = 1;
    render();
    showStatus("Backup saved. All chats cleared.");
  } catch (e) {
    err("Clear all failed:", e);
    showStatus("Clear all failed (see console).", "error");
  } finally {
    openModal(byId("clearAllModal"), false);
  }
}

/* ---------- Save ---------- */
async function onSaveClick() {
  try {
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    if (!tab) {
      showStatus("No active tab.", "warn");
      return;
    }
    const rawUrl = tab.url || "";
    if (!isChatUrl(rawUrl)) {
      showStatus("Open a ChatGPT conversation (/c/...) and try again.", "warn");
      return;
    }

    const url = normalizeUrl(rawUrl);
    const existing = ITEMS.find((x) => x.url === url);
    if (existing) {
      showStatus("This chat is already saved — highlighted it.");
      focusAndFlashItem(existing.id);
      return;
    }

    const note = prompt("Add a note (optional):", "") || "";
    const item = {
      id: crypto.randomUUID(),
      url,
      title: tab.title || "Untitled Chat",
      note,
      createdAt: new Date().toISOString()
    };
    ITEMS.unshift(item);
    await saveItems(ITEMS);
    currentPage = 1;
    render();
    showStatus("Saved!");
  } catch (e) {
    err("Save click failed:", e);
    showStatus("Save failed (see console).", "error");
  }
}

/* ---------- Theme (sync) ---------- */
async function initTheme() {
  try {
    const res = await STORAGE_FLAGS.get({ [THEME_KEY]: false });
    const dark = !!res[THEME_KEY];
    document.body.classList.toggle("dark", dark);
    byId("darkModeToggle").setAttribute("aria-pressed", String(dark));
  } catch {}
}

/* ---------- Help (sync) ---------- */
async function initHelpOnce() {
  try {
    const res = await STORAGE_FLAGS.get({ [HELP_KEY]: false });
    const hide = !!res[HELP_KEY];
    if (!hide) openModal(byId("helpModal"), true);
  } catch {}
}

/* ---------- Init ---------- */
async function init() {
  // Theme & help
  await initTheme();
  await initHelpOnce();

  // Migrate (once) from sync → local
  await migrateFromSyncToLocalIfNeeded();

  // Load items (from local)
  ITEMS = await loadItems();
  render();
  updateStorageUI();

  // Controls
  byId("saveBtn").addEventListener("click", onSaveClick);
  byId("searchBar").addEventListener("input", () => {
    currentPage = 1;
    render();
  });
  byId("sortSelect").addEventListener("change", (e) => {
    sortBy = e.target.value;
    currentPage = 1;
    render();
  });
  byId("pageSize").addEventListener("change", (e) => {
    pageSize = parseInt(e.target.value, 10) || 10;
    currentPage = 1;
    render();
  });

  // Pagination
  byId("prevBtn").addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      render();
    }
  });
  byId("nextBtn").addEventListener("click", () => {
    const q = (byId("searchBar").value || "").toLowerCase().trim();
    const pages = Math.max(
      1,
      Math.ceil(
        ITEMS.filter(
          (x) =>
            (x.title || "").toLowerCase().includes(q) ||
            (x.note || "").toLowerCase().includes(q)
        ).length / pageSize
      )
    );
    if (currentPage < pages) {
      currentPage++;
      render();
    }
  });

  // Theme toggle (persist in sync)
  byId("darkModeToggle").addEventListener("click", () => {
    const dark = !document.body.classList.contains("dark");
    document.body.classList.toggle("dark", dark);
    byId("darkModeToggle").setAttribute("aria-pressed", String(dark));
    STORAGE_FLAGS.set({ [THEME_KEY]: dark }).catch(() => {});
  });

  // Help modal
  byId("helpBtn").addEventListener("click", () =>
    openModal(byId("helpModal"), true)
  );
  byId("helpClose").addEventListener("click", () =>
    openModal(byId("helpModal"), false)
  );
  byId("helpOk").addEventListener("click", async () => {
    const dont = byId("dontShowHelp").checked;
    if (dont) {
      try {
        await STORAGE_FLAGS.set({ [HELP_KEY]: true });
      } catch {}
    }
    openModal(byId("helpModal"), false);
  });

  // Import / Export
  byId("importBtn").addEventListener("click", () => byId("importFile").click());
  byId("importFile").addEventListener("change", (e) =>
    handleImportFile(e.target.files?.[0])
  );
  byId("exportBtn").addEventListener("click", () =>
    exportItems().catch(() => {})
  );

  // Clear All modal
  byId("clearAllBtn").addEventListener("click", openClearAllModal);
  byId("clearAllClose").addEventListener("click", () =>
    openModal(byId("clearAllModal"), false)
  );
  byId("clearAllCancel").addEventListener("click", () =>
    openModal(byId("clearAllModal"), false)
  );
  byId("clearAllConfirm").addEventListener("click", confirmClearAll);

  // Ensure list starts at top
  byId("listContainer").scrollTop = 0;
}

document.addEventListener("DOMContentLoaded", init);
